TEXT_CLASSIFICATION = [
    ".csv",
    ".jsonl",
]
